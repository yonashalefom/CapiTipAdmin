package com.capitipalism.ui.adapters;

import android.content.Context;
import android.content.Intent;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.capitipalism.R;
import com.capitipalism.classes.CapiUserManager;
import com.capitipalism.ui.profile.Profile;
import com.capitipalism.ui.register.Register;
import com.capitipalism.ui.search.SearchUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;

//
public class UsersSearchAdapter extends RecyclerView.Adapter<UsersSearchAdapter.SearchViewHolder> {
    private Context context;
    private ArrayList<String> profileIDList;
    private ArrayList<String> userNameList;
    private ArrayList<String> profileImageList;
    private ArrayList<String> userStatusList;

    static class SearchViewHolder extends RecyclerView.ViewHolder {
        ImageView profileImage, user_sponsor_indicator;
        TextView userName, userStatus;
        ConstraintLayout userHolderMainContainer;

        SearchViewHolder(View itemView) {
            super(itemView);
            userHolderMainContainer = itemView.findViewById(R.id.user_holder_main_container);
            userName = itemView.findViewById(R.id.user_name);
            profileImage = itemView.findViewById(R.id.user_image);
            userStatus = itemView.findViewById(R.id.user_status);
            user_sponsor_indicator = itemView.findViewById(R.id.user_sponsor_indicator);
        }
    }

    public UsersSearchAdapter(Context context, ArrayList<String> profileIDList, ArrayList<String> profileImageList, ArrayList<String> userNameList, ArrayList<String> userStatusList) {
        this.context = context;
        this.profileIDList = profileIDList;
        this.profileImageList = profileImageList;
        this.userNameList = userNameList;
        this.userStatusList = userStatusList;
    }

    @NonNull
    @Override
    public UsersSearchAdapter.SearchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.layout_user_item, parent, false);
        return new SearchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SearchViewHolder holder, int position) {
        System.out.println("*************************************");
        System.out.println("View Bind at position: " + position);

        holder.userName.setText(userNameList.get(position));
        holder.userStatus.setText(userStatusList.get(position));

        final String image = profileImageList.get(position);

        int userImagePlaceholder;

        // Random r = new Random();
        // int rand = r.nextInt((5 - 1) + 1) + 1;

        // if(rand == 1){
        //     userImagePlaceholder = R.drawable.ic_user_placeholder_avatar_1;
        // } else if(rand == 2){
        //     userImagePlaceholder = R.drawable.ic_user_placeholder_avatar_2;
        // } else if(rand == 3){
        //     userImagePlaceholder = R.drawable.ic_user_placeholder_avatar_3;
        // } else if(rand == 4){
        //     userImagePlaceholder = R.drawable.ic_user_placeholder_avatar_4;
        // } else if(rand == 5){
        //     userImagePlaceholder = R.drawable.ic_user_placeholder_avatar_5;
        // } else {
        userImagePlaceholder = R.drawable.ic_user_placeholder_avatar_1;
        // }

        if (!image.equals("default")) {
            Picasso.with(context)
                    .load(image)
                    .resize((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 50, context.getResources().getDisplayMetrics()), (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 50, context.getResources().getDisplayMetrics()))
                    .centerCrop()
                    .networkPolicy(NetworkPolicy.OFFLINE)
                    .placeholder(userImagePlaceholder)
                    .into(holder.profileImage, new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError() {
                            Picasso.with(context)
                                    .load(image)
                                    .resize((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 50, context.getResources().getDisplayMetrics()), (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 50, context.getResources().getDisplayMetrics()))
                                    .centerCrop()
                                    .placeholder(userImagePlaceholder)
                                    .error(userImagePlaceholder)
                                    .into(holder.profileImage);
                        }
                    });
        } else {
            holder.profileImage.setImageResource(userImagePlaceholder);
        }

        holder.userHolderMainContainer.setOnClickListener(view -> {
            // Toast.makeText(context, "Clicked " + profileIDList.get(position), Toast.LENGTH_LONG).show();
            Intent userProfileIntent = new Intent(context.getApplicationContext(), Profile.class);
            userProfileIntent.putExtra("userID", profileIDList.get(position));
            context.startActivity(userProfileIntent);
        });

        CapiUserManager.loadUserData(context);
        if (CapiUserManager.userDataExists(context)) {
            // region Beta Feature
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference reference = database.getReference("Users").child(profileIDList.get(position));
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    // If the currently logged in user sponsored the loaded user, it shows indicator on the loaded user's profile
                    final String userSponsorID = Objects.requireNonNull(dataSnapshot.child("userSponsorID").getValue()).toString();
                    if (Objects.requireNonNull(userSponsorID).compareToIgnoreCase(CapiUserManager.getCurrentUserID()) == 0) {
                        holder.user_sponsor_indicator.setVisibility(View.VISIBLE);
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
            // endregion
        }
        System.out.println("*************************************");
        // holder.userName.setOnClickListener(v -> Toast.makeText(context, "Full Name Clicked", Toast.LENGTH_SHORT).show());
    }

    @Override
    public int getItemCount() {
        return userNameList.size();
    }
}
