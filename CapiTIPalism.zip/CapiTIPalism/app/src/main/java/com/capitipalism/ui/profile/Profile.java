package com.capitipalism.ui.profile;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.capitipalism.R;
import com.capitipalism.classes.CapiUserManager;
import com.capitipalism.ui.adapters.UsersSearchAdapter;
import com.capitipalism.ui.imageviewer.FullScreenActivity;
import com.capitipalism.ui.search.SearchUser;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Callback;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;
import jahirfiquitiva.libs.fabsmenu.FABsMenu;
import jahirfiquitiva.libs.fabsmenu.TitleFAB;

public class Profile extends AppCompatActivity {
    private FirebaseRecyclerAdapter usersOnesReferenceFirebaseRecyclerAdapter;
    ArrayList<String> userIDList1stGen;
    ArrayList<String> userNameList1stGen;
    ArrayList<String> profileImageList1stGen;
    ArrayList<String> userStatusList1stGen;

    ArrayList<String> userIDList2ndGen;
    ArrayList<String> userNameList2ndGen;
    ArrayList<String> profileImageList2ndGen;
    ArrayList<String> userStatusList2ndGen;
    UsersSearchAdapter userOnesAdapter, userTwosAdapter;

    // region Firebase Variables
    private DatabaseReference userDatabase, usersOnesDatabaseReference, usersTwosDatabaseReference;
    private ValueEventListener userListener, usersOnesReferenceListener, friendsListener;
    // endregion

    private LinearLayout personalInfo, experience, review;
    private TextView profileSponsoredBy, personalInfoBtn, experienceBtn, reviewBtn, name, profile_user_id, userFacebook, userTwitter, userInstagram, profile_direct_signup_description, profile_indirect_signup_description;

    private CircleImageView image;
    private FABsMenu menu;
    private TitleFAB button1, button2, button3, button4;
    private ImageView searchUsers, profile_back_button, profile_sponsored_by_icon;

    private String userID;

    private RecyclerView userOnesSignupsRecyclerView;
    private RecyclerView userTwosSignupsRecyclerView;

    // region [Override] On Create
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        userID = getIntent().getStringExtra("userID");
        initUI();
        initEventHandlers();
        initCurrentUsersOnes();
        initCurrentUserTwos();
        // initCurrentUserTwosAnother();
    }
    // endregion

    // region Init UI
    private void initUI() {
        bindUIElements();
    }
    // endregion

    // region Bind UI Elements
    private void bindUIElements() {
        // region Final Vars
        name = findViewById(R.id.profile_name);
        profile_user_id = findViewById(R.id.profile_user_id);
        // status = findViewById(R.id.profile_status);
        image = findViewById(R.id.profile_image);
        menu = findViewById(R.id.profile_fabs_menu);
        userFacebook = findViewById(R.id.profile_facebook);
        userTwitter = findViewById(R.id.profile_twitter);
        userInstagram = findViewById(R.id.profile_instagram);
        searchUsers = findViewById(R.id.profile_register_new_users);
        // endregion
        personalInfo = findViewById(R.id.personalinfo);
        experience = findViewById(R.id.experience);
        review = findViewById(R.id.review);
        personalInfoBtn = findViewById(R.id.users_list_count);
        experienceBtn = findViewById(R.id.experiencebtn);
        reviewBtn = findViewById(R.id.reviewbtn);
        profile_back_button = findViewById(R.id.profile_back_button);
        profile_sponsored_by_icon = findViewById(R.id.profile_sponsored_by_icon);

        profileSponsoredBy = findViewById(R.id.profile_sponsored_by);
        userOnesSignupsRecyclerView = findViewById(R.id.user_ones_signups_list);
        userTwosSignupsRecyclerView = findViewById(R.id.user_twos_signups_list);
        profile_direct_signup_description = findViewById(R.id.profile_direct_signup_description);
        profile_indirect_signup_description = findViewById(R.id.profile_indirect_signup_description);

        userIDList1stGen = new ArrayList<>();
        userNameList1stGen = new ArrayList<>();
        profileImageList1stGen = new ArrayList<>();
        userStatusList1stGen = new ArrayList<>();

        userIDList2ndGen = new ArrayList<>();
        userNameList2ndGen = new ArrayList<>();
        profileImageList2ndGen = new ArrayList<>();
        userStatusList2ndGen = new ArrayList<>();

        /*making personal info visible*/
        personalInfo.setVisibility(View.VISIBLE);
        experience.setVisibility(View.GONE);
        review.setVisibility(View.GONE);
    }
    // endregion

    // region Init Event Handlers
    private void initEventHandlers() {
        personalInfoBtn.setOnClickListener(v -> {
            personalInfo.setVisibility(View.VISIBLE);
            experience.setVisibility(View.GONE);
            review.setVisibility(View.GONE);
            personalInfoBtn.setTextColor(getResources().getColor(R.color.capitipalism_primary));
            experienceBtn.setTextColor(getResources().getColor(R.color.main_gray));
            reviewBtn.setTextColor(getResources().getColor(R.color.main_gray));
        });

        experienceBtn.setOnClickListener(v -> {
            personalInfo.setVisibility(View.GONE);
            experience.setVisibility(View.VISIBLE);
            review.setVisibility(View.GONE);
            personalInfoBtn.setTextColor(getResources().getColor(R.color.main_gray));
            experienceBtn.setTextColor(getResources().getColor(R.color.capitipalism_primary));
            reviewBtn.setTextColor(getResources().getColor(R.color.main_gray));
        });

        reviewBtn.setOnClickListener(v -> {
            personalInfo.setVisibility(View.GONE);
            experience.setVisibility(View.GONE);
            review.setVisibility(View.VISIBLE);
            personalInfoBtn.setTextColor(getResources().getColor(R.color.main_gray));
            experienceBtn.setTextColor(getResources().getColor(R.color.main_gray));
            reviewBtn.setTextColor(getResources().getColor(R.color.capitipalism_primary));
        });

        searchUsers.setOnClickListener(view -> {
            startActivity(new Intent(Profile.this, SearchUser.class));
        });

        profile_indirect_signup_description.setOnClickListener(view -> {
            userTwosAdapter = new UsersSearchAdapter(Profile.this, userIDList2ndGen, profileImageList2ndGen, userNameList2ndGen, userStatusList2ndGen);
            userTwosSignupsRecyclerView.setAdapter(userTwosAdapter);
        });

        profileSponsoredBy.setOnClickListener(v -> {
            Intent userProfileIntent = new Intent(Profile.this, Profile.class);
            userProfileIntent.putExtra("userID", profileSponsoredBy.getText().toString());
            startActivity(userProfileIntent);
        });

        profile_back_button.setOnClickListener(view -> {
            onBackPressed();
        });
    }
    // endregion

    // region [Override] On Start
    protected void onStart() {
        super.onStart();

        if (userDatabase != null && userListener != null) {
            userDatabase.removeEventListener(userListener);
        }

        // Initialize/Update realtime user data such as name, status, image
        userDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child(userID);
        userDatabase.keepSynced(true); // For offline use
        userListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                try {
                    String firstName = Objects.requireNonNull(dataSnapshot.child("userFirstName").getValue()).toString();
                    String lastName = Objects.requireNonNull(dataSnapshot.child("userLastName").getValue()).toString();
                    String userSponsoredBy = Objects.requireNonNull(dataSnapshot.child("userSponsorID").getValue()).toString();
                    String layoutName = firstName + " " + lastName;
                    String layoutUserID = Objects.requireNonNull(dataSnapshot.child("userID").getValue()).toString();
                    String layoutStatus = Objects.requireNonNull(dataSnapshot.child("status").getValue()).toString();
                    final String layoutImage = Objects.requireNonNull(dataSnapshot.child("image").getValue()).toString();

                    String userFacebookLoaded = Objects.requireNonNull(dataSnapshot.child("facebook").getValue()).toString();
                    String userTwitterLoaded = Objects.requireNonNull(dataSnapshot.child("twitter").getValue()).toString();
                    String userInstagramLoaded = Objects.requireNonNull(dataSnapshot.child("instagram").getValue()).toString();

                    name.setText(layoutName);
                    profile_user_id.setText("ID: " + layoutUserID);
                    profileSponsoredBy.setText(userSponsoredBy);
                    // status.setText(layoutStatus);

                    userFacebook.setText(userFacebookLoaded);
                    userTwitter.setText(userTwitterLoaded);
                    userInstagram.setText(userInstagramLoaded);

                    // region Fetch User Profile Picture
                    if (!layoutImage.equals("default")) {
                        Picasso.with(getApplicationContext())
                                .load(layoutImage)
                                .resize((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 180, getResources().getDisplayMetrics()), (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 180, getResources().getDisplayMetrics()))
                                .centerCrop()
                                .networkPolicy(NetworkPolicy.OFFLINE)
                                .placeholder(R.drawable.ic_user_placeholder_avatar_1)
                                .error(R.drawable.ic_user_placeholder_avatar_1)
                                .into(image, new Callback() {
                                    @Override
                                    public void onSuccess() {

                                    }

                                    @Override
                                    public void onError() {
                                        Picasso.with(getApplicationContext())
                                                .load(layoutImage)
                                                .resize((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 180, getResources().getDisplayMetrics()), (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 180, getResources().getDisplayMetrics()))
                                                .centerCrop()
                                                .placeholder(R.drawable.ic_user_placeholder_avatar_1)
                                                .error(R.drawable.ic_user_placeholder_avatar_1)
                                                .into(image);
                                    }
                                });

                        image.setOnClickListener(view -> {
                            Intent intent = new Intent(Profile.this, FullScreenActivity.class);
                            intent.putExtra("imageUrl", layoutImage);
                            startActivity(intent);
                        });
                    } else {
                        image.setImageResource(R.drawable.ic_user_placeholder_avatar_1);
                    }
                    // endregion

                    CapiUserManager.loadUserData(getApplicationContext());
                    if (userID.equals(CapiUserManager.getCurrentUserID()) || userSponsoredBy.equals(CapiUserManager.getCurrentUserID())) {
                        if (userSponsoredBy.equals(CapiUserManager.getCurrentUserID())) {
                            profile_sponsored_by_icon.setBackground(getResources().getDrawable(R.drawable.circular_golden_bordersolid));
                            profile_sponsored_by_icon.setImageResource(R.drawable.ic_capitipalism_golden_star);
                        }
                        initializeCurrentUserProfile();
                    } else {
                        menu.setVisibility(View.INVISIBLE);
                    }
                } catch (Exception e) {
                    Log.d("PROFILE ACTIVITY", "userDatabase listener exception: " + e.getMessage());
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.d("PROFILE ACTIVITY", "userDatabase listener failed: " + databaseError.getMessage());
            }
        };
        userDatabase.addValueEventListener(userListener);
    }
    // endregion

    // region [Override] On Stop
    @Override
    protected void onStop() {
        super.onStop();
    }
    // endregion

    // region [Override] On Activity Result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK) {
            Uri url = data.getData();
            System.out.println("*******************************");
            System.out.println("Image URL: " + url);
            System.out.println("*******************************");

            // Uploading selected picture
            StorageReference file = FirebaseStorage.getInstance().getReference().child("profile_images").child(userID + ".jpg");
            file.putFile(Objects.requireNonNull(url)).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    String imageUrl = Objects.requireNonNull(task.getResult().getDownloadUrl()).toString();

                    // Updating image on user data
                    userDatabase.child("image").setValue(imageUrl).addOnCompleteListener(task1 -> {
                        if (task1.isSuccessful()) {
                            Toast.makeText(Profile.this, "Picture updated", Toast.LENGTH_SHORT).show();
                        } else {
                            Log.d("Profile", "updateImage listener failed: " + Objects.requireNonNull(task1.getException()).getMessage());
                        }
                    });
                } else {
                    Log.d("Profile", "uploadImage listener failed: " + Objects.requireNonNull(task.getException()).getMessage());
                }
            });
        }
    }
    // endregion

    // region [Override] On Back Pressed
    @Override
    public void onBackPressed() {
        if (menu.isExpanded()) {
            menu.collapse();
        } else {
            super.onBackPressed();
        }
    }
    // endregion

    // region Init My Profile
    public void initializeCurrentUserProfile() {
        menu.setVisibility(View.VISIBLE);
        // region Fab Button Initializations
        if (button1 != null) {
            menu.removeButton(button1);
        }

        if (button2 != null) {
            menu.removeButton(button2);
        }

        if (button3 != null) {
            menu.removeButton(button3);
        }

        if (button4 != null) {
            menu.removeButton(button4);
        }
        // endregion

        // region Button To Edit User Name
        button1 = new TitleFAB(Profile.this);
        button1.setTitle("Change Name");
        button1.setBackgroundColor(getResources().getColor(R.color.capitipalism_primary));
        button1.setRippleColor(getResources().getColor(R.color.capitipalism_accent));
        button1.setImageResource(R.drawable.ic_edit_white_24dp);
        button1.setOnClickListener(view -> {
            menu.collapse();

            AlertDialog.Builder builder = new AlertDialog.Builder(Profile.this);
            builder.setTitle("Enter your Name:");

            View mView = Profile.this.getLayoutInflater().inflate(R.layout.name_dialog, null);

            final EditText firstName = mView.findViewById(R.id.name_dialog_first_name);
            final EditText lastName = mView.findViewById(R.id.name_dialog_last_name);

            builder.setPositiveButton("Update", (dialogInterface, i) -> {
                final String newFirstName = firstName.getText().toString();
                final String newLastName = lastName.getText().toString();

                if (newFirstName.length() < 1 || newFirstName.length() > 24 || newLastName.length() < 1 || newLastName.length() > 24) {
                    Toast.makeText(Profile.this, "Length can't exceed no more than 24 characters.", Toast.LENGTH_LONG).show();
                    dialogInterface.dismiss();
                } else {
                    // Updating on status on user data

                    // userDatabase.child("userFirstName").setValue(newStatus).addOnCompleteListener(task -> {
                    //     if (task.isSuccessful()) {
                    //         Toast.makeText(Profile.this, "Status updated", Toast.LENGTH_SHORT).show();
                    //     } else {
                    //         Toast.makeText(Profile.this, Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_LONG).show();
                    //     }
                    // });

                    Map<String, Object> userNameUpdateMap = new HashMap<>();
                    userNameUpdateMap.put("userFirstName", newFirstName);
                    userNameUpdateMap.put("userLastName", newLastName);

                    userDatabase.updateChildren(userNameUpdateMap).addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(Profile.this, "User Name updated", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(Profile.this, Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            });

            builder.setNegativeButton("Cancel", (dialogInterface, i) -> dialogInterface.dismiss());

            builder.setView(mView);
            AlertDialog dialog = builder.create();
            dialog.show();
        });
        menu.addButton(button1);
        // endregion

        // region Button To Change Profile Picture
        button2 = new TitleFAB(Profile.this);
        button2.setTitle("Change Image");
        button2.setBackgroundColor(getResources().getColor(R.color.capitipalism_primary));
        button2.setRippleColor(getResources().getColor(R.color.capitipalism_accent));
        button2.setImageResource(R.drawable.ic_image_white_24dp);
        button2.setOnClickListener(view -> {
            Intent gallery = new Intent();
            gallery.setType("image/*");
            gallery.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(gallery, "Select Image"), 1);

            menu.collapse();
        });
        menu.addButton(button2);
        // endregion

        // region Button To Change User Status (About Info)
        button3 = new TitleFAB(Profile.this);
        button3.setTitle("Change Status");
        button3.setBackgroundColor(getResources().getColor(R.color.capitipalism_primary));
        button3.setRippleColor(getResources().getColor(R.color.capitipalism_accent));
        button3.setImageResource(R.drawable.ic_edit_white_24dp);
        button3.setOnClickListener(view -> {
            menu.collapse();

            AlertDialog.Builder builder = new AlertDialog.Builder(Profile.this);
            builder.setTitle("Enter your new Status:");

            View mView = Profile.this.getLayoutInflater().inflate(R.layout.status_dialog, null);

            final EditText tmp = mView.findViewById(R.id.status_text);

            builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    final String newStatus = tmp.getText().toString();

                    if (newStatus.length() < 1 || newStatus.length() > 1000) {
                        Toast.makeText(Profile.this, "Status must be between 1-1000 characters.", Toast.LENGTH_LONG).show();
                        dialogInterface.dismiss();
                    } else {

                        // Updating on status on user data
                        userDatabase.child("status").setValue(newStatus).addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                Toast.makeText(Profile.this, "Status updated", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(Profile.this, Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                }
            });

            builder.setNegativeButton("Cancel", (dialogInterface, i) -> dialogInterface.dismiss());

            builder.setView(mView);
            AlertDialog dialog = builder.create();
            dialog.show();
        });
        menu.addButton(button3);
        // endregion

        // region Button To Edit Social Links
        button4 = new TitleFAB(Profile.this);
        button4.setTitle("Change Social Links");
        button4.setBackgroundColor(getResources().getColor(R.color.capitipalism_primary));
        button4.setRippleColor(getResources().getColor(R.color.capitipalism_accent));
        button4.setImageResource(R.drawable.ic_edit_white_24dp);
        button4.setOnClickListener(view -> {
            menu.collapse();

            AlertDialog.Builder builder = new AlertDialog.Builder(Profile.this);
            builder.setTitle("Enter your Social Links:");

            View mView = Profile.this.getLayoutInflater().inflate(R.layout.social_links_dialog, null);

            final EditText userFB = mView.findViewById(R.id.social_links_dialog_facebook);
            final EditText userTwi = mView.findViewById(R.id.social_links_dialog_twitter);
            final EditText userInsta = mView.findViewById(R.id.social_links_dialog_instagram);

            builder.setPositiveButton("Update", (dialogInterface, i) -> {
                final String newUserFacebook = userFB.getText().toString();
                final String newUserTwitter = userTwi.getText().toString();
                final String newUserInstagram = userInsta.getText().toString();

                if (newUserFacebook.length() < 1 || newUserFacebook.length() > 24 || newUserTwitter.length() < 1 || newUserTwitter.length() > 24 || newUserInstagram.length() < 1 || newUserInstagram.length() > 24) {
                    Toast.makeText(Profile.this, "Length can't exceed no more than 24 characters.", Toast.LENGTH_LONG).show();
                    dialogInterface.dismiss();
                } else {
                    // Updating on status on user data

                    // userDatabase.child("userFirstName").setValue(newStatus).addOnCompleteListener(task -> {
                    //     if (task.isSuccessful()) {
                    //         Toast.makeText(Profile.this, "Status updated", Toast.LENGTH_SHORT).show();
                    //     } else {
                    //         Toast.makeText(Profile.this, Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_LONG).show();
                    //     }
                    // });

                    Map<String, Object> socialLinksUpdateMap = new HashMap<>();
                    socialLinksUpdateMap.put("facebook", newUserFacebook);
                    socialLinksUpdateMap.put("instagram", newUserTwitter);
                    socialLinksUpdateMap.put("twitter", newUserInstagram);

                    userDatabase.updateChildren(socialLinksUpdateMap).addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(Profile.this, "Social Links updated", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(Profile.this, Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            });

            builder.setNegativeButton("Cancel", (dialogInterface, i) -> dialogInterface.dismiss());

            builder.setView(mView);
            AlertDialog dialog = builder.create();
            dialog.show();
        });
        menu.addButton(button4);
        // endregion
    }
    // endregion

    // region TRY LOADING USERS SPONSORS
    private void initCurrentUsersOnes() {
        usersOnesDatabaseReference = FirebaseDatabase
                .getInstance()
                .getReference()
                .child("Users")
        ;

        userOnesSignupsRecyclerView.setHasFixedSize(true);
        userOnesSignupsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // userOnesSignupsRecyclerView

        usersOnesDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                userNameList1stGen.clear();
                userOnesSignupsRecyclerView.removeAllViews();

                int counter = 0;

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String userSponsorID = snapshot.child("userSponsorID").getValue(String.class);

                    String uID = snapshot.getKey();
                    String userName = snapshot.child("userFirstName").getValue(String.class) + " " + snapshot.child("userLastName").getValue(String.class) + " - ID: " + uID;
                    String profilePic = snapshot.child("image").getValue(String.class);
                    String status = snapshot.child("status").getValue(String.class);

                    if (Objects.requireNonNull(userSponsorID).compareToIgnoreCase(userID) == 0) {
                        userIDList1stGen.add(uID);
                        userNameList1stGen.add(userName);
                        profileImageList1stGen.add(profilePic);
                        userStatusList1stGen.add(status);
                        counter++;
                    }

                    if (counter == 25) {
                        break;
                    }
                }

                profile_direct_signup_description.setText(userID + " Registerd " + counter + " Users.");
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        userOnesAdapter = new UsersSearchAdapter(Profile.this, userIDList1stGen, profileImageList1stGen, userNameList1stGen, userStatusList1stGen);
        userOnesSignupsRecyclerView.setAdapter(userOnesAdapter);
        // friendsDatabase.keepSynced(true); // For offline use
    }

    private void initCurrentUserTwos() {
        usersTwosDatabaseReference = FirebaseDatabase
                .getInstance()
                .getReference()
                .child("Users");

        userTwosSignupsRecyclerView.setHasFixedSize(true);
        userTwosSignupsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // userTwosSignupsRecyclerView

        userNameList2ndGen.clear();
        userTwosSignupsRecyclerView.removeAllViews();

        final int[] firstGenCounter = {0};
        final int[] secondGenCounter = {0};

        usersTwosDatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                System.out.println("\n\n########################################################\n\n");
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String firstGenUserSponsorID = snapshot.child("userSponsorID").getValue(String.class);
                    String firstGenUserID = snapshot.getKey();
                    // System.out.println("First Gen Spon ID: " + firstGenUserSponsorID + " firstGenUserID: " + firstGenUserID);

                    if (Objects.requireNonNull(firstGenUserSponsorID).compareToIgnoreCase(userID) == 0) {
                        usersTwosDatabaseReference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot1) {
                                for (DataSnapshot snapshot1 : dataSnapshot1.getChildren()) {
                                    String secondGenUserSponsorID = snapshot1.child("userSponsorID").getValue(String.class);

                                    String secondGenUserID = snapshot1.getKey();
                                    String secondGenUserName = snapshot1.child("userFirstName").getValue(String.class) + " " + snapshot1.child("userLastName").getValue(String.class) + " - ID: " + secondGenUserID;
                                    String secondGenProfilePic = snapshot1.child("image").getValue(String.class);
                                    String secondGenStatus = snapshot1.child("status").getValue(String.class);

                                    if (Objects.requireNonNull(secondGenUserSponsorID).compareToIgnoreCase(firstGenUserID) == 0) {

                                        System.out.println("\n\nFound " + secondGenUserID);
                                        userIDList2ndGen.add(secondGenUserID);
                                        userNameList2ndGen.add(secondGenUserName);
                                        profileImageList2ndGen.add(secondGenProfilePic);
                                        userStatusList2ndGen.add(secondGenStatus);
                                        secondGenCounter[0]++;
                                    }

                                    // System.out.println("COUNTER: " + secondGenCounter[0]);

                                    if (secondGenCounter[0] == 50) {
                                        break;
                                    }
                                }

                                // profile_indirect_signup_description.setText(userID + " Registerd " + secondGenCounter[0] + " Users.");
                                profile_indirect_signup_description.setText("Users Registered By " + firstGenUserSponsorID + " Registerd " + secondGenCounter[0] + " Users.");
                                userTwosAdapter = new UsersSearchAdapter(Profile.this, userIDList2ndGen, profileImageList2ndGen, userNameList2ndGen, userStatusList2ndGen);
                                userTwosSignupsRecyclerView.setAdapter(userTwosAdapter);
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });

                        firstGenCounter[0]++;
                    }


                    if (firstGenCounter[0] == 25) {
                        break;
                    }
                }

                System.out.println("\n\n########################################################\n\n");
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        // Timer myTimer = new Timer();
        // myTimer.schedule(new TimerTask() {
        //     @Override
        //     public void run() {
        //         runOnUiThread(() -> {
        //             userTwosAdapter = new UsersSearchAdapter(Profile.this, userIDList2ndGen, profileImageList2ndGen, userNameList2ndGen, userStatusList2ndGen);
        //             userTwosSignupsRecyclerView.setAdapter(userTwosAdapter);
        //         });
        //
        //     }
        //
        // }, 0, 1000);


        System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^SET ADAPTER^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        // friendsDatabase.keepSynced(true); // For offline use
    }
    // endregion
}
