package com.capitipalism.classes;

public class AppState {
    // region Global Booleans
    private static boolean isUserLoaded;
    // endregion

    private static String currentUserID;

    public static String getCurrentUserID() {
        return currentUserID;
    }

    public static void setCurrentUserID(String currentUserID) {
        AppState.currentUserID = currentUserID;
    }

    public static boolean isUserLoaded() {
        return isUserLoaded;
    }

    public static void setUserLoaded(boolean userLoaded) {
        isUserLoaded = userLoaded;
    }
}
